-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : dim. 02 oct. 2022 à 19:45
-- Version du serveur : 10.4.24-MariaDB
-- Version de PHP : 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `aeek_kassere`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `date_admin` datetime DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `nom` varchar(225) NOT NULL,
  `prenom` varchar(225) NOT NULL,
  `email_valid` int(1) NOT NULL DEFAULT 0,
  `mot_de_passe` varchar(225) DEFAULT NULL,
  `slug` varchar(225) DEFAULT NULL,
  `phone` varchar(225) DEFAULT NULL,
  `iso_phone` varchar(225) DEFAULT NULL,
  `dial_phone` varchar(225) DEFAULT NULL,
  `fonction` varchar(225) DEFAULT NULL,
  `niveau` varchar(225) DEFAULT NULL,
  `biographie` varchar(225) DEFAULT NULL,
  `facebook` varchar(225) DEFAULT NULL,
  `twitter` varchar(225) DEFAULT NULL,
  `linkedin` varchar(225) DEFAULT NULL,
  `instagram` varchar(225) DEFAULT NULL,
  `photo` varchar(225) DEFAULT NULL,
  `role` int(1) DEFAULT 0,
  `bloquer` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id_admin`, `date_admin`, `email`, `nom`, `prenom`, `email_valid`, `mot_de_passe`, `slug`, `phone`, `iso_phone`, `dial_phone`, `fonction`, `niveau`, `biographie`, `facebook`, `twitter`, `linkedin`, `instagram`, `photo`, `role`, `bloquer`) VALUES
(1, '2022-05-30 11:14:40', 'zie.nanien@gmail.com', 'Ouattara', 'Gnelezie', 1, '$2y$12$pOGTVYKlboX25jpPsGfnbO5swWhVQW05ejZ9U0sUjw9NhmYVjYzH.', 'ouattara', '0546859936', 'ci', '225', 'D&eacute;veloppeur web', '', 'e lorem ipsum est, en imprimerie, une suite de mots sans signification utilis&eacute;e &agrave; titre provisoire pour calibrer une mise en page, le texte d&eacute;finitif venant remplacer le faux-texte d&egrave;s qu\\\'il est p', '', '', '', '', '62948daa2bc12.jpg', 1, 1),
(2, '2022-06-05 19:00:00', 'octavie@gmail.com', 'Gnelezie Arouna', 'Ouattara', 0, NULL, 'gnelezie-arouna', '000000000', 'ci', '225', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `email_2` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
